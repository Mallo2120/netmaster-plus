import { useEffect, useRef } from 'react';
import { Engine, Scene, Vector3, HemisphericLight, MeshBuilder } from '@babylonjs/core';

interface ScenarioViewerProps {
  id: number;
}

/**
 * ScenarioViewer renders a simple Babylon.js scene as a placeholder for the 3D lab environment.
 * In a full implementation this component would load the scenario definition, create
 * devices (switches, PCs, routers), patch cables and interactive CLI panels.
 */
export default function ScenarioViewer({ id }: ScenarioViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (!canvasRef.current) return;
    const engine = new Engine(canvasRef.current, true);
    const scene = new Scene(engine);
    new HemisphericLight('light', new Vector3(0, 1, 0), scene);
    const box = MeshBuilder.CreateBox('box', { size: 2 }, scene);
    box.position.y = 1;
    const ground = MeshBuilder.CreateGround('ground', { width: 6, height: 6 }, scene);
    engine.runRenderLoop(() => {
      scene.render();
    });
    window.addEventListener('resize', () => {
      engine.resize();
    });
    return () => {
      engine.dispose();
    };
  }, []);
  return (
    <div className="w-full h-64 border border-primary rounded">
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  );
}