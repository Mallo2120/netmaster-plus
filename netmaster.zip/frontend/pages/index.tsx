import { useEffect, useState, useContext } from 'react';
import Link from 'next/link';
import { ExperienceContext } from './_app';

interface Track {
  id: number;
  name: string;
  description: string;
}

const tracks: Track[] = [
  { id: 1, name: 'Networking Fundamentals', description: 'Foundations of networks, OSI model, IP addressing.' },
  { id: 2, name: 'Network Implementations', description: 'Switching, VLANs, wireless, routing technologies.' },
  { id: 3, name: 'Network Operations', description: 'Monitoring, documentation, change management.' },
  { id: 4, name: 'Network Security', description: 'Security concepts, threats, and mitigation.' },
  { id: 5, name: 'Network Troubleshooting', description: 'Structured troubleshooting and common issues.' },
];

export default function Home() {
  const { level, setLevel } = useContext(ExperienceContext);
  return (
    <div className="min-h-screen flex flex-col items-center p-8">
      <header className="mb-10 text-center">
        <h1 className="text-4xl font-bold text-primary mb-2">Welcome to NetMaster+</h1>
        <p className="text-lg max-w-xl">
          An adaptive training platform for the CompTIA Network+ certification. Choose your experience level and begin your journey.
        </p>
        <div className="mt-4">
          <label htmlFor="experience" className="mr-2">Experience Level:</label>
          <select
            id="experience"
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            className="text-dark p-1 rounded"
          >
            <option value="beginner">Beginner (0–1 yrs)</option>
            <option value="intermediate">Intermediate (1–3 yrs)</option>
            <option value="advanced">Advanced (3+ yrs)</option>
          </select>
        </div>
      </header>
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl">
        {tracks.map((track) => (
          <div key={track.id} className="border border-primary rounded-lg p-6 bg-black/50 hover:bg-black/60 transition">
            <h2 className="text-2xl font-semibold mb-2 text-secondary">{track.name}</h2>
            <p className="text-sm mb-4">{track.description}</p>
            <Link href={`/tracks/${track.id}`}>
              <span className="inline-block px-4 py-2 bg-primary text-dark rounded hover:bg-secondary transition cursor-pointer">Start Track</span>
            </Link>
          </div>
        ))}
      </section>
    </div>
  );
}