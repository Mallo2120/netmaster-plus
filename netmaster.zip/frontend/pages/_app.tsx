import '@/styles/globals.css';
import type { AppProps } from 'next/app';
import { createContext, useState } from 'react';

// Context for storing user experience level (beginner/intermediate/advanced)
export const ExperienceContext = createContext<{ level: string; setLevel: (level: string) => void }>({
  level: 'beginner',
  setLevel: () => {},
});

export default function App({ Component, pageProps }: AppProps) {
  const [level, setLevel] = useState('beginner');
  return (
    <ExperienceContext.Provider value={{ level, setLevel }}>
      <Component {...pageProps} />
    </ExperienceContext.Provider>
  );
}