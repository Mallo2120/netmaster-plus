import { useRouter } from 'next/router';
import useSWR from 'swr';
import axios from 'axios';
import { useState } from 'react';
import Link from 'next/link';

const fetcher = (url: string) => axios.get(url).then(res => res.data);

interface Question {
  id: number;
  question: string;
  choices: string[];
}

export default function QuizPage() {
  const router = useRouter();
  const { id } = router.query;
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;
  const { data: questions, error } = useSWR<Question[]>(id ? `${apiUrl}/quizzes/track/${id}` : null, fetcher);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [result, setResult] = useState<any>(null);

  const handleSelect = (questionId: number, choiceIdx: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: choiceIdx }));
  };

  const handleSubmit = async () => {
    const payload = Object.entries(answers).map(([qid, sel]) => ({
      question_id: Number(qid),
      selected: sel as number,
    }));
    try {
      const res = await axios.post(`${apiUrl}/quizzes/grade`, payload);
      setResult(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  if (!id) return <div className="p-8">Loading...</div>;
  if (error) return <div className="p-8">Failed to load quiz.</div>;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Link href={`/tracks/${id}`} className="text-secondary underline mb-4 inline-block">← Back to Track</Link>
      <h1 className="text-3xl font-bold text-primary mb-4">Quiz - Track {id}</h1>
      {questions ? (
        <>
          {result ? (
            <div>
              <p className="text-xl mb-4">You answered {result.correct_count} of {result.total} correctly.</p>
              <ul className="space-y-2">
                {result.detailed.map((detail: any) => (
                  <li key={detail.question_id} className="bg-black/50 p-3 rounded">
                    <p className="font-medium">Question {detail.question_id}: {detail.is_correct ? 'Correct' : 'Incorrect'}</p>
                    {!detail.is_correct && (
                      <p className="text-sm text-red-400">Correct answer: choice {detail.correct + 1}</p>
                    )}
                  </li>
                ))}
              </ul>
              <button onClick={() => setResult(null)} className="mt-6 px-4 py-2 bg-primary text-dark rounded hover:bg-secondary">Retake Quiz</button>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
              <ul className="space-y-6">
                {questions.map((q) => (
                  <li key={q.id} className="border border-primary rounded p-4 bg-black/50">
                    <p className="mb-2 font-medium">{q.question}</p>
                    <div className="space-y-1">
                      {q.choices.map((choice: string, idx: number) => (
                        <label key={idx} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            name={`q${q.id}`}
                            value={idx}
                            checked={answers[q.id] === idx}
                            onChange={() => handleSelect(q.id, idx)}
                            className="text-primary"
                          />
                          <span>{choice}</span>
                        </label>
                      ))}
                    </div>
                  </li>
                ))}
              </ul>
              <button type="submit" className="mt-6 px-4 py-2 bg-primary text-dark rounded hover:bg-secondary">Submit Quiz</button>
            </form>
          )}
        </>
      ) : (
        <div>Loading questions...</div>
      )}
    </div>
  );
}