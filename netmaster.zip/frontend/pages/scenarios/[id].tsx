import { useRouter } from 'next/router';
import useSWR from 'swr';
import axios from 'axios';
import Link from 'next/link';

const fetcher = (url: string) => axios.get(url).then(res => res.data);

export default function ScenarioPage() {
  const router = useRouter();
  const { id } = router.query;
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;
  const { data: scenario, error } = useSWR(id ? `${apiUrl}/scenarios/${id}` : null, fetcher);
  if (!id) return <div className="p-8">Loading...</div>;
  if (error) return <div className="p-8">Failed to load scenario.</div>;
  return (
    <div className="p-8 max-w-4xl mx-auto">
      {scenario ? (
        <>
          <Link href={`/tracks/${scenario.track_id}`} className="text-secondary underline mb-4 inline-block">← Back to Track</Link>
          <h1 className="text-3xl font-bold text-primary mb-2">{scenario.title}</h1>
          <p className="mb-4">{scenario.objective}</p>
          <p className="italic text-sm mb-6">Difficulty: {scenario.difficulty}</p>
          <h2 className="text-2xl font-semibold text-secondary mb-2">Tasks</h2>
          <ol className="list-decimal list-inside mb-6 space-y-1">
            {scenario.definition.tasks.map((task: any, idx: number) => (
              <li key={idx}>{task.description}</li>
            ))}
          </ol>
          <h2 className="text-2xl font-semibold text-secondary mb-2">Scenario Definition (JSON)</h2>
          <pre className="bg-black/50 p-4 rounded overflow-x-auto text-sm">
            {JSON.stringify(scenario.definition, null, 2)}
          </pre>
          <p className="mt-4 text-sm text-gray-400">Interactive labs are coming soon! For now, review the scenario definition and think about how you would solve the problem.</p>
        </>
      ) : (
        <div>Loading...</div>
      )}
    </div>
  );
}