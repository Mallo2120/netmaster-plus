import { useRouter } from 'next/router';
import useSWR from 'swr';
import axios from 'axios';
import Link from 'next/link';
import { useContext } from 'react';
import { ExperienceContext } from '../_app';

const fetcher = (url: string) => axios.get(url).then(res => res.data);

export default function TrackPage() {
  const router = useRouter();
  const { id } = router.query;
  const { level } = useContext(ExperienceContext);
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;

  const { data: lessons, error: lessonErr } = useSWR(id ? `${apiUrl}/lessons/track/${id}` : null, fetcher);
  const { data: scenarios, error: scenarioErr } = useSWR(
    id ? `${apiUrl}/scenarios/track/${id}?difficulty=${level}` : null,
    fetcher
  );

  if (!id) return <div className="p-8">Loading...</div>;
  if (lessonErr || scenarioErr) return <div className="p-8">Failed to load content.</div>;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Link href="/" className="text-secondary underline mb-4 inline-block">← Back to Tracks</Link>
      <h1 className="text-3xl font-bold text-primary mb-4">Track {id}</h1>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-secondary mb-2">Lessons</h2>
        {lessons ? (
          <ul className="space-y-2">
            {lessons.map((lesson: any) => (
              <li key={lesson.id} className="border border-primary rounded p-4 bg-black/50 hover:bg-black/60 transition">
                <Link href={`/lessons/${lesson.id}`} className="font-medium text-primary">
                  {lesson.title}
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <div>Loading lessons...</div>
        )}
      </section>
      <section>
        <h2 className="text-2xl font-semibold text-secondary mb-2">Scenarios</h2>
        {scenarios ? (
          <ul className="space-y-2">
            {scenarios.map((sc: any) => (
              <li key={sc.id} className="border border-secondary rounded p-4 bg-black/50 hover:bg-black/60 transition">
                <Link href={`/scenarios/${sc.id}`} className="font-medium text-secondary">
                  {sc.title} ({sc.difficulty})
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <div>Loading scenarios...</div>
        )}
      </section>
      <div className="mt-8">
        <Link href={`/quizzes/${id}`} className="px-4 py-2 bg-primary text-dark rounded hover:bg-secondary">Take Quiz</Link>
      </div>
    </div>
  );
}