import useSWR from 'swr';
import axios from 'axios';
import { useState } from 'react';
import Link from 'next/link';

const fetcher = (url: string) => axios.get(url).then(res => res.data);

export default function ExamPage() {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;
  const { data: questions, error } = useSWR(`${apiUrl}/exams`, fetcher);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [result, setResult] = useState<any>(null);

  const handleSelect = (questionId: number, choiceIdx: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: choiceIdx }));
  };
  const handleSubmit = async () => {
    const payload = Object.entries(answers).map(([qid, sel]) => ({ question_id: Number(qid), selected: sel as number }));
    try {
      const res = await axios.post(`${apiUrl}/exams/grade`, payload);
      setResult(res.data);
    } catch (err) {
      console.error(err);
    }
  };
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <Link href="/" className="text-secondary underline mb-4 inline-block">← Back Home</Link>
      <h1 className="text-3xl font-bold text-primary mb-4">Final Exam Simulation</h1>
      {error && <p>Failed to load exam questions.</p>}
      {!questions && <p>Loading exam...</p>}
      {questions && (
        <>
          {result ? (
            <div>
              <p className="text-xl mb-4">You answered {result.correct_count} of {result.total} correctly.</p>
              <p className="text-xl mb-4">Pass threshold: {result.pass_score}%</p>
              <p className="text-2xl font-bold mb-6">{result.passed ? 'Congratulations! You passed.' : 'Keep studying!'}</p>
              <button onClick={() => setResult(null)} className="px-4 py-2 bg-primary text-dark rounded hover:bg-secondary">Retake Exam</button>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
              <p className="text-sm mb-4">Answer all questions. The exam is untimed in this MVP.</p>
              <ul className="space-y-6 max-h-[60vh] overflow-y-auto pr-2">
                {questions.map((q: any, idx: number) => (
                  <li key={q.id} className="border border-primary rounded p-4 bg-black/50">
                    <p className="mb-2 font-medium">Q{idx + 1}: {q.question}</p>
                    <div className="space-y-1">
                      {q.choices.map((choice: string, cIdx: number) => (
                        <label key={cIdx} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            name={`q${q.id}`}
                            value={cIdx}
                            checked={answers[q.id] === cIdx}
                            onChange={() => handleSelect(q.id, cIdx)}
                            className="text-primary"
                          />
                          <span>{choice}</span>
                        </label>
                      ))}
                    </div>
                  </li>
                ))}
              </ul>
              <button type="submit" className="mt-6 px-4 py-2 bg-primary text-dark rounded hover:bg-secondary">Submit Exam</button>
            </form>
          )}
        </>
      )}
    </div>
  );
}