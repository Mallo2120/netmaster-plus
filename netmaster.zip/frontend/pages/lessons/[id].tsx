import { useRouter } from 'next/router';
import useSWR from 'swr';
import axios from 'axios';
import Link from 'next/link';

const fetcher = (url: string) => axios.get(url).then(res => res.data);

export default function LessonPage() {
  const router = useRouter();
  const { id } = router.query;
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;
  const { data: lesson, error } = useSWR(id ? `${apiUrl}/lessons/${id}` : null, fetcher);
  if (!id) return <div className="p-8">Loading...</div>;
  if (error) return <div className="p-8">Failed to load lesson.</div>;
  return (
    <div className="p-8 max-w-3xl mx-auto">
      <Link href={lesson ? `/tracks/${lesson.track_id}` : '#'} className="text-secondary underline mb-4 inline-block">← Back to Track</Link>
      {lesson ? (
        <>
          <h1 className="text-3xl font-bold text-primary mb-4">{lesson.title}</h1>
          <article className="prose prose-invert mb-6" dangerouslySetInnerHTML={{ __html: lesson.content.replace(/\n/g, '<br/>') }} />
          {lesson.diagrams && lesson.diagrams.length > 0 && (
            <div className="grid gap-4 mb-6">
              {lesson.diagrams.map((url: string, idx: number) => (
                <img key={idx} src={url} alt={`Diagram ${idx + 1}`} className="w-full rounded" />
              ))}
            </div>
          )}
          {lesson.practice_questions && lesson.practice_questions.length > 0 && (
            <div className="mt-4">
              <h2 className="text-xl font-semibold mb-2 text-secondary">Practice Questions</h2>
              <p className="text-sm">Take the quiz for this lesson in the track quiz section.</p>
            </div>
          )}
        </>
      ) : (
        <div>Loading...</div>
      )}
    </div>
  );
}