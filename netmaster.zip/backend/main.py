"""Entry point for the NetMaster+ backend."""

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

try:
    # when executed as module (e.g. uvicorn netmaster.backend.main:app)
    from .app import create_app  # type: ignore
except ImportError:
    # fallback for running directly from backend directory
    from app import create_app  # type: ignore


def get_settings():
    """Return environment-based settings."""
    return {
        "frontend_url": os.getenv("FRONTEND_URL", "http://localhost:3000"),
    }


def create_fastapi_app() -> FastAPI:
    app = create_app()
    settings = get_settings()
    # Allow CORS for frontend
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[settings["frontend_url"]],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return app


app = create_fastapi_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))