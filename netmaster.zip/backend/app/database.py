"""Simple in-memory database loader.

This module reads JSON files from the `seed_data` directory and exposes
dictionaries with lessons, scenarios, quizzes and exam questions. In a real
deployment you would connect to Supabase or another Postgres instance
instead of loading static JSON files.  This in-memory approach keeps the
backend simple for the MVP.
"""

import json
import os
from typing import Dict, List, Any

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SEED_DIR = os.path.join(BASE_DIR, "seed_data")

def _load_json(filename: str) -> List[Dict[str, Any]]:
    path = os.path.join(SEED_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


class DataStore:
    """Singleton-like loader for seed data."""

    lessons: List[Dict[str, Any]] = []
    scenarios: List[Dict[str, Any]] = []
    quizzes: List[Dict[str, Any]] = []
    exams: List[Dict[str, Any]] = []

    @classmethod
    def load(cls):
        cls.lessons = _load_json("lessons_seed.json")
        cls.scenarios = _load_json("scenarios_seed.json")
        cls.quizzes = _load_json("quizzes_seed.json")
        cls.exams = _load_json("exam_seed.json")

# Load data at import time
DataStore.load()