"""Define Pydantic models representing our domain objects."""
from typing import List, Optional
from pydantic import BaseModel


class Lesson(BaseModel):
    id: int
    title: str
    track_id: int
    content: str
    diagrams: List[str] = []
    practice_questions: List[int] = []  # references to quiz question IDs


class Scenario(BaseModel):
    id: int
    title: str
    track_id: int
    objective: str
    difficulty: str  # beginner, intermediate, advanced
    definition: dict


class QuizQuestion(BaseModel):
    id: int
    track_id: int
    question: str
    choices: List[str]
    answer: int  # index into choices
    explanation: Optional[str] = None


class ExamQuestion(BaseModel):
    id: int
    track_id: int
    question: str
    choices: List[str]
    answer: int
    explanation: Optional[str] = None