# NetMaster+ Backend

from fastapi import FastAPI
from .routers import lessons, scenarios, quizzes, exams


def create_app() -> FastAPI:
    """Factory function to create the FastAPI application"""
    app = FastAPI(
        title="NetMaster+ API",
        description="REST API for the NetMaster+ adaptive Network+ training platform",
        version="0.1.0",
    )
    # Include routers
    app.include_router(lessons.router, prefix="/lessons", tags=["lessons"])
    app.include_router(scenarios.router, prefix="/scenarios", tags=["scenarios"])
    app.include_router(quizzes.router, prefix="/quizzes", tags=["quizzes"])
    app.include_router(exams.router, prefix="/exams", tags=["exams"])
    return app
