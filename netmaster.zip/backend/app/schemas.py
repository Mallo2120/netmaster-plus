"""Response/Request schemas for FastAPI.

These schemas define the shape of the objects returned by API endpoints. They
extend the underlying models to hide sensitive fields or to tweak the field
names for API consumers.
"""
from typing import List, Optional
from pydantic import BaseModel


class LessonOut(BaseModel):
    id: int
    title: str
    track_id: int
    content: str
    diagrams: List[str] = []
    practice_questions: List[int] = []


class ScenarioOut(BaseModel):
    id: int
    title: str
    track_id: int
    objective: str
    difficulty: str
    definition: dict


class QuizQuestionOut(BaseModel):
    id: int
    track_id: int
    question: str
    choices: List[str]


class QuizAnswerIn(BaseModel):
    question_id: int
    selected: int


class QuizResultOut(BaseModel):
    correct_count: int
    total: int
    detailed: List[dict]


class ExamQuestionOut(BaseModel):
    id: int
    track_id: int
    question: str
    choices: List[str]


class ExamAnswerIn(BaseModel):
    question_id: int
    selected: int


class ExamResultOut(BaseModel):
    correct_count: int
    total: int
    pass_score: int
    passed: bool
    detailed: List[dict]