"""Lesson endpoints for NetMaster+ API."""

from fastapi import APIRouter, HTTPException
from typing import List
from ..database import DataStore
from ..schemas import LessonOut


router = APIRouter()


@router.get("/", response_model=List[LessonOut])
def list_lessons() -> List[LessonOut]:
    """Return all lessons."""
    return [LessonOut(**lesson) for lesson in DataStore.lessons]


@router.get("/{lesson_id}", response_model=LessonOut)
def get_lesson(lesson_id: int) -> LessonOut:
    """Return a single lesson by ID."""
    for lesson in DataStore.lessons:
        if lesson["id"] == lesson_id:
            return LessonOut(**lesson)
    raise HTTPException(status_code=404, detail="Lesson not found")


@router.get("/track/{track_id}", response_model=List[LessonOut])
def get_lessons_by_track(track_id: int) -> List[LessonOut]:
    """Return lessons filtered by track."""
    return [LessonOut(**lesson) for lesson in DataStore.lessons if lesson["track_id"] == track_id]
