"""Final exam endpoints for NetMaster+ API."""

from fastapi import APIRouter, HTTPException
from typing import List, Dict
import random
from ..database import DataStore
from ..schemas import ExamQuestionOut, ExamAnswerIn, ExamResultOut

router = APIRouter()

PASS_SCORE = 75  # percent required to pass


@router.get("/", response_model=List[ExamQuestionOut])
def get_exam_questions(limit: int = 90) -> List[ExamQuestionOut]:
    """Return a random selection of exam questions. Defaults to 90, but will return fewer if the seed pool is smaller."""
    questions = DataStore.exams
    sample = questions if len(questions) <= limit else random.sample(questions, k=limit)
    return [ExamQuestionOut(id=q["id"], track_id=q["track_id"], question=q["question"], choices=q["choices"]) for q in sample]


@router.post("/grade", response_model=ExamResultOut)
def grade_exam(answers: List[ExamAnswerIn]) -> ExamResultOut:
    """Grade a submitted exam."""
    correct_count = 0
    detailed: List[Dict] = []
    question_map = {q["id"]: q for q in DataStore.exams}
    for ans in answers:
        q = question_map.get(ans.question_id)
        if not q:
            raise HTTPException(status_code=404, detail=f"Question {ans.question_id} not found")
        is_correct = ans.selected == q["answer"]
        if is_correct:
            correct_count += 1
        detailed.append({
            "question_id": q["id"],
            "selected": ans.selected,
            "correct": q["answer"],
            "is_correct": is_correct,
            "explanation": q.get("explanation"),
        })
    total = len(answers)
    score_percent = (correct_count / total * 100) if total else 0
    passed = score_percent >= PASS_SCORE
    return ExamResultOut(correct_count=correct_count, total=total, pass_score=PASS_SCORE, passed=passed, detailed=detailed)