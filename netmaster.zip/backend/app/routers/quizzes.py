"""Quiz endpoints for NetMaster+ API."""

from fastapi import APIRouter, HTTPException
from typing import List, Dict
from ..database import DataStore
from ..schemas import QuizQuestionOut, QuizAnswerIn, QuizResultOut

router = APIRouter()


@router.get("/track/{track_id}", response_model=List[QuizQuestionOut])
def get_quiz_questions_by_track(track_id: int) -> List[QuizQuestionOut]:
    """Return quiz questions for a given track."""
    questions = [q for q in DataStore.quizzes if q["track_id"] == track_id]
    return [QuizQuestionOut(id=q["id"], track_id=q["track_id"], question=q["question"], choices=q["choices"]) for q in questions]


@router.post("/grade", response_model=QuizResultOut)
def grade_quiz(answers: List[QuizAnswerIn]) -> QuizResultOut:
    """Grade a submitted quiz and return the result."""
    correct_count = 0
    detailed: List[Dict] = []
    question_map = {q["id"]: q for q in DataStore.quizzes}
    for ans in answers:
        q = question_map.get(ans.question_id)
        if not q:
            raise HTTPException(status_code=404, detail=f"Question {ans.question_id} not found")
        is_correct = ans.selected == q["answer"]
        if is_correct:
            correct_count += 1
        detailed.append({
            "question_id": q["id"],
            "selected": ans.selected,
            "correct": q["answer"],
            "is_correct": is_correct,
            "explanation": q.get("explanation"),
        })
    return QuizResultOut(correct_count=correct_count, total=len(answers), detailed=detailed)
