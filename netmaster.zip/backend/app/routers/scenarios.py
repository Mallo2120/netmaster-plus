"""Scenario endpoints for NetMaster+ API."""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..database import DataStore
from ..schemas import ScenarioOut

router = APIRouter()


@router.get("/", response_model=List[ScenarioOut])
def list_scenarios(difficulty: Optional[str] = Query(None, description="Filter by difficulty level")) -> List[ScenarioOut]:
    """Return all scenarios or filter by difficulty."""
    scenarios = DataStore.scenarios
    if difficulty:
        scenarios = [s for s in scenarios if s["difficulty"].lower() == difficulty.lower()]
    return [ScenarioOut(**scenario) for scenario in scenarios]


@router.get("/{scenario_id}", response_model=ScenarioOut)
def get_scenario(scenario_id: int) -> ScenarioOut:
    """Return a single scenario by ID."""
    for scenario in DataStore.scenarios:
        if scenario["id"] == scenario_id:
            return ScenarioOut(**scenario)
    raise HTTPException(status_code=404, detail="Scenario not found")


@router.get("/track/{track_id}", response_model=List[ScenarioOut])
def get_scenarios_by_track(track_id: int, difficulty: Optional[str] = Query(None)) -> List[ScenarioOut]:
    """Return scenarios filtered by track and optionally difficulty."""
    scenarios = [s for s in DataStore.scenarios if s["track_id"] == track_id]
    if difficulty:
        scenarios = [s for s in scenarios if s["difficulty"].lower() == difficulty.lower()]
    return [ScenarioOut(**scenario) for scenario in scenarios]
