# NetMaster+ 🚀

NetMaster+ is an adaptive training platform built for learners preparing for the CompTIA® Network+ certification.  Whether you’re completely new to networking or an experienced engineer brushing up on your skills, NetMaster+ adapts to your experience level and guides you through the five exam domains with interactive lessons, 3D labs, checkpoint quizzes and a full exam simulator.

## Features

* **Adaptive onboarding** – choose beginner, intermediate or advanced experience and the system adjusts the level of guidance, hints and complexity in your labs and questions.
* **Tracks aligned with Network+ domains** – Networking Fundamentals, Network Implementations, Network Operations, Network Security and Network Troubleshooting.
* **Lessons & quizzes** – every track contains reading material, diagrams and embedded practice questions mapped to exam objectives.
* **Interactive scenarios** – 3D labs built with Babylon.js allow you to drag‑and‑drop cables, run CLI commands and fix mis‑configurations in a simulated network environment.
* **Checkpoint quizzes and final exam** – test your readiness with track‑level quizzes and a 90‑question mock exam that mirrors the real test.
* **Adaptive coaching with GPT‑5 Pro** – your reasoning answers are evaluated and feedback is provided inline to help you learn from mistakes.

## Tech Stack

- **Frontend:** [Next.js](https://nextjs.org/) (TypeScript) with [Tailwind CSS](https://tailwindcss.com/) for styling.
- **3D Labs:** [Babylon.js](https://www.babylonjs.com/) is used to render lab scenes and provide drag‑and‑drop interactions. A mock CLI panel simulates commands like `ping`, `traceroute` and `show vlan`.
- **Backend:** [FastAPI](https://fastapi.tiangolo.com/) provides a REST API to serve lessons, scenarios, quizzes and exam questions.  Authentication and persistence are handled via **Supabase**.
- **Database:** [Supabase](https://supabase.com/) (PostgreSQL) with row‑level security.  Tables are seeded with starter lessons, scenarios and a question bank.
- **Deployment:** The frontend is deployed to **Vercel** and the backend API to **Render** or **Fly.io**.  Supabase hosts the database and provides authentication.

## Repository Structure

```
netmaster/
├── README.md               # This file
├── .env.example            # Environment variable template
├── backend/                # FastAPI application
│   ├── app/
│   │   ├── __init__.py
│   │   ├── database.py      # DB connection & models
│   │   ├── models.py        # Pydantic models & SQLAlchemy definitions
│   │   ├── schemas.py       # Response/request schemas
│   │   ├── routers/
│   │   │   ├── auth.py      # Auth routes (placeholder)
│   │   │   ├── lessons.py   # Lesson endpoints
│   │   │   ├── scenarios.py # Scenario endpoints
│   │   │   ├── quizzes.py   # Quiz endpoints
│   │   │   └── exams.py     # Final exam endpoint
│   │   ├── seed_data/       # JSON seed data for DB
│   │   │   ├── lessons_seed.json
│   │   │   ├── scenarios_seed.json
│   │   │   ├── quizzes_seed.json
│   │   │   └── exam_seed.json
│   ├── main.py             # FastAPI entry point
│   └── requirements.txt    # Python dependencies
├── frontend/               # Next.js application
│   ├── pages/
│   │   ├── index.tsx       # Landing page
│   │   ├── tracks/         # Dynamic track pages
│   │   │   └── [id].tsx
│   │   ├── lessons/        # Dynamic lesson pages
│   │   │   └── [id].tsx
│   │   ├── scenarios/      # Scenario UI
│   │   │   └── [id].tsx
│   │   ├── quizzes/        # Quiz pages
│   │   │   └── [id].tsx
│   │   └── exam.tsx        # Final exam page
│   ├── components/         # Reusable UI components
│   ├── lib/                # API clients and helpers
│   ├── styles/             # Tailwind CSS and globals
│   ├── tsconfig.json
│   ├── next.config.js
│   ├── postcss.config.js
│   ├── tailwind.config.js
│   └── package.json
├── scenarios/              # Example YAML scenario definitions
│   ├── vlan_misconfiguration.yaml
│   ├── subnetting_exercise.yaml
│   ├── wireless_interference_resolution.yaml
│   ├── dhcp_scope_exhaustion.yaml
│   └── cable_fault_identification.yaml
└── seeds/                  # Additional seed data for future migrations
    ├── lessons.json
    ├── scenarios.json
    ├── quizzes.json
    └── exam.json
```

## Getting Started

### Prerequisites

* Node.js 18+ and npm
* Python 3.9+
* A Supabase project and associated API keys

### Installation

1. **Clone the repo**

```sh
git clone https://example.com/netmaster.git
cd netmaster
```

2. **Copy environment variables**

Create a `.env` file in both `backend/` and `frontend/` by copying `.env.example` and replacing the placeholder values:

```sh
cp .env.example .env
cp .env.example backend/.env
cp .env.example frontend/.env
```

Fill in your Supabase URL and anon/service keys where indicated.

3. **Install backend dependencies**

```sh
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

4. **Run the backend locally**

```sh
uvicorn app.main:app --reload --port 8000
```

5. **Install frontend dependencies**

```sh
cd ../frontend
npm install
```

6. **Run the frontend locally**

```sh
npm run dev
```

The frontend will be available at `http://localhost:3000`, making API requests to `http://localhost:8000` by default.  Adjust the environment variables if your ports differ.

### Seeding Data

After configuring your Supabase project, run the provided seed scripts or manually import the JSON files in `backend/app/seed_data/` into your database.  This will populate the tables with sample lessons, scenarios and quiz questions.

### Deployment

1. **Frontend:** Connect the `frontend/` directory to Vercel and set the environment variables for Supabase.  Vercel will automatically build and deploy the Next.js app.
2. **Backend:** Deploy the FastAPI service to Render, Fly.io or your preferred provider.  Ensure your environment variables match those used in development.
3. **Database:** Supabase hosts the Postgres database and provides user authentication.  Configure row‑level security policies to ensure users can only access their own progress.

### Contributing

Pull requests are welcome!  Please open an issue first to discuss your proposed changes.  For major changes, please open an issue to discuss what you would like to change.
